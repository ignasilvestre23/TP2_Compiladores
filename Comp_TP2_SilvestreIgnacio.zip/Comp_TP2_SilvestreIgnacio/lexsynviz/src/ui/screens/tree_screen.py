"""Pantalla del árbol de derivación, sincronizada con el paso actual del
analizador sintáctico (misma StepPlayer que ParserScreen). Soporta pan
(arrastrar con el mouse) y zoom (rueda del mouse) dentro del lienzo."""
from __future__ import annotations

import pygame

from .. import theme
from ..widgets import Button, NavBar
from ...grammar import EPS
from ...tree import compute_layout, visible_nodes

CANVAS = pygame.Rect(30, 110, 1220, 500)
NODE_R = 20
X_GAP = 90
Y_GAP = 90
MIN_ZOOM = 0.3
MAX_ZOOM = 3.0


class TreeScreen:
    def __init__(self, app):
        self.app = app
        self.player = app.parser_player  # comparte índice con ParserScreen
        self.navbar = NavBar((30, 630, 900, 34), self.player)
        self.reset_view_btn = Button((950, 630, 150, 34), "Centrar vista", self._reset_view)
        self.zoom = 1.0
        self.pan = [0.0, 0.0]
        self.dragging = False
        self.drag_start = (0, 0)
        self.pan_start = (0.0, 0.0)

    def _reset_view(self):
        self.zoom = 1.0
        self.pan = [0.0, 0.0]

    def on_activate(self):
        self._reset_view()

    def handle_event(self, event):
        if self.navbar.handle_event(event):
            return
        if self.reset_view_btn.handle_event(event):
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if CANVAS.collidepoint(event.pos):
                self.dragging = True
                self.drag_start = event.pos
                self.pan_start = tuple(self.pan)
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            dx = event.pos[0] - self.drag_start[0]
            dy = event.pos[1] - self.drag_start[1]
            self.pan = [self.pan_start[0] + dx, self.pan_start[1] + dy]
        elif event.type == pygame.MOUSEWHEEL and CANVAS.collidepoint(pygame.mouse.get_pos()):
            factor = 1.15 if event.y > 0 else (1 / 1.15)
            self.zoom = max(MIN_ZOOM, min(MAX_ZOOM, self.zoom * factor))

    def update(self, dt):
        self.player.update(dt)

    def draw(self, surface):
        surface.fill(theme.BG)
        f_title = theme.font(20, bold=True)
        surface.blit(f_title.render("Árbol de derivación (crece con cada paso del analizador sintáctico)",
                                     True, theme.TEXT), (30, 55))
        f_hint = theme.font(13)
        surface.blit(f_hint.render("Arrastrá con el mouse para mover la vista, rueda para hacer zoom",
                                    True, theme.TEXT_DIM), (30, 80))

        result = self.app.parser_result
        if result is None or result.tree is None:
            f = theme.font(16)
            surface.blit(f.render("Todavía no se analizó ninguna entrada.", True, theme.TEXT_DIM), (30, 100))
            return

        pygame.draw.rect(surface, theme.PANEL_BG, CANVAS, border_radius=theme.RADIUS)
        pygame.draw.rect(surface, theme.PANEL_BORDER, CANVAS, width=1, border_radius=theme.RADIUS)

        compute_layout(result.tree)
        nodes, edges = visible_nodes(result.tree, self.player.index)

        if nodes:
            x_gap = X_GAP * self.zoom
            y_gap = Y_GAP * self.zoom
            node_r = max(6, int(NODE_R * self.zoom))
            max_x = max(n.x for n in nodes)
            width_px = max(max_x * x_gap, 1)
            base_x = CANVAS.x + max(20, (CANVAS.width - width_px) / 2)
            base_y = CANVAS.y + 40 * self.zoom

            def px(node):
                return (base_x + node.x * x_gap + self.pan[0],
                        base_y + node.y * y_gap + self.pan[1])

            clip = surface.get_clip()
            surface.set_clip(CANVAS)

            for parent, child in edges:
                pygame.draw.line(surface, theme.PANEL_BORDER, px(parent), px(child), 2)

            f = theme.font(max(9, int(14 * self.zoom)))
            f_val = theme.font(max(8, int(12 * self.zoom)))
            for node in nodes:
                x, y = px(node)
                is_new = node.step_created == self.player.index
                if node.symbol == EPS:
                    color = theme.SKIP_GRAY
                elif node.is_terminal:
                    color = theme.OK_GREEN
                else:
                    color = theme.ACCENT
                if is_new:
                    pygame.draw.circle(surface, theme.TEXT, (int(x), int(y)), node_r + 3, width=2)
                pygame.draw.circle(surface, color, (int(x), int(y)), node_r)
                pygame.draw.circle(surface, theme.PANEL_BORDER, (int(x), int(y)), node_r, width=1)
                label = f.render(node.symbol, True, theme.BG)
                surface.blit(label, label.get_rect(center=(x, y)))

                if node.is_terminal and node.symbol != EPS and node.value is not None:
                    val_label = f_val.render(repr(node.value), True, theme.TEXT_DIM)
                    surface.blit(val_label, val_label.get_rect(center=(x, y + node_r + 12 * self.zoom)))

            surface.set_clip(clip)
        else:
            f = theme.font(14)
            surface.blit(f.render("(sin nodos todavía)", True, theme.TEXT_DIM),
                          (CANVAS.x + 20, CANVAS.y + 20))

        self.navbar.draw(surface)
        self.reset_view_btn.draw(surface)

        f = theme.font(15)
        if not result.steps[self.player.index].ok:
            msg = f"Análisis detenido por error: {result.steps[self.player.index].message}"
            surface.blit(f.render(msg, True, theme.ERROR_RED), (30, 675))
        elif result.accepted and self.player.index == self.player.max_index:
            surface.blit(f.render("Árbol de derivación completo. Cadena aceptada.", True, theme.OK_GREEN),
                          (30, 675))
