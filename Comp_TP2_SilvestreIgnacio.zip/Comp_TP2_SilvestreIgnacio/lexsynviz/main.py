"""Punto de entrada: visualizador de análisis léxico y sintáctico con pygame."""
from src.ui.app import App

if __name__ == "__main__":
    App().run()
