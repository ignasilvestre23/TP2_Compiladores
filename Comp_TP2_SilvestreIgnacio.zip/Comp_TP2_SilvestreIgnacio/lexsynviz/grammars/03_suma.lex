NUM = [0-9]+
SUMA = \+
SKIP: WS = \s+
