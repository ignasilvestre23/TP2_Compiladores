"""Parser LL(1) dirigido por tabla: produce la traza (pila/entrada/acción)
paso a paso y construye el árbol de derivación por la izquierda."""
from __future__ import annotations

from dataclasses import dataclass

from .grammar import END, EPS, Grammar, LL1Table
from .lexer import Token
from .tree import TreeNode


@dataclass
class ParserStep:
    index: int
    stack: str
    remaining: str
    action: str
    ok: bool
    message: str


@dataclass
class ParserResult:
    steps: list
    tree: TreeNode | None
    accepted: bool
    has_error: bool


def run_ll1(tokens: list, table: LL1Table) -> ParserResult:
    grammar: Grammar = table.grammar
    root = TreeNode(symbol=grammar.start, step_created=0, is_terminal=False)
    stack = [(END, None), (grammar.start, root)]
    seq = list(tokens) + [Token(type=END, lexeme="$", start=-1, end=-1)]
    ip = 0
    steps: list = []
    step_index = 0
    accepted = False
    has_error = False

    def stack_str():
        return " ".join(sym for sym, _ in stack)

    def remaining_str():
        return " ".join(tok.type for tok in seq[ip:])

    while True:
        top_sym, top_node = stack[-1]
        lookahead = seq[ip].type

        cur_stack = stack_str()
        cur_remaining = remaining_str()

        if top_sym == END and lookahead == END:
            steps.append(ParserStep(
                index=step_index, stack=cur_stack, remaining=cur_remaining,
                action="ACEPTAR", ok=True, message="Cadena aceptada por la gramática",
            ))
            accepted = True
            break

        if top_sym not in grammar.productions:
            # terminal (o $) en el tope
            if top_sym == lookahead:
                if top_node is not None:
                    top_node.value = seq[ip].lexeme
                stack.pop()
                ip += 1
                steps.append(ParserStep(
                    index=step_index, stack=cur_stack, remaining=cur_remaining,
                    action=f"MATCH {top_sym}", ok=True,
                    message=f"Coincide el terminal '{top_sym}' con la entrada",
                ))
            else:
                steps.append(ParserStep(
                    index=step_index, stack=cur_stack, remaining=cur_remaining,
                    action="ERROR",
                    ok=False,
                    message=f"Se esperaba '{top_sym}' pero se encontró '{lookahead}'",
                ))
                has_error = True
                break
        else:
            key = (top_sym, lookahead)
            if key not in table.table:
                steps.append(ParserStep(
                    index=step_index, stack=cur_stack, remaining=cur_remaining,
                    action="ERROR",
                    ok=False,
                    message=f"No hay entrada en la tabla LL(1) para ({top_sym}, {lookahead})",
                ))
                has_error = True
                break

            alt = table.table[key]
            stack.pop()
            if alt:
                children = [
                    TreeNode(symbol=s, step_created=step_index, is_terminal=(s not in grammar.productions))
                    for s in alt
                ]
                top_node.children = children
                for sym, node in reversed(list(zip(alt, children))):
                    stack.append((sym, node))
            else:
                eps_node = TreeNode(symbol=EPS, step_created=step_index, is_terminal=True)
                top_node.children = [eps_node]

            steps.append(ParserStep(
                index=step_index, stack=cur_stack, remaining=cur_remaining,
                action=f"OUTPUT {grammar.production_to_str(top_sym, alt)}",
                ok=True,
                message=f"Se expande {top_sym}",
            ))

        step_index += 1

    return ParserResult(steps=steps, tree=root, accepted=accepted, has_error=has_error)
