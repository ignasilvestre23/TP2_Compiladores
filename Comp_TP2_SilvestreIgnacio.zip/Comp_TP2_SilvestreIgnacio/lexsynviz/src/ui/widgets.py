"""Widgets mínimos de pygame: Button, TabBar, Table, TextBox (una o varias
líneas) y Slider. Sin dependencias externas."""
from __future__ import annotations

import pygame

from . import theme


class Button:
    def __init__(self, rect, label, on_click=None, enabled=True):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.on_click = on_click
        self.enabled = enabled
        self.hover = False

    def handle_event(self, event) -> bool:
        if not self.enabled:
            return False
        if event.type == pygame.MOUSEMOTION:
            self.hover = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                if self.on_click:
                    self.on_click()
                return True
        return False

    def draw(self, surface):
        if not self.enabled:
            color = theme.BUTTON_DISABLED
            text_color = theme.TEXT_DIM
        elif self.hover:
            color = theme.BUTTON_HOVER
            text_color = theme.TEXT
        else:
            color = theme.BUTTON_BG
            text_color = theme.TEXT
        pygame.draw.rect(surface, color, self.rect, border_radius=theme.RADIUS)
        pygame.draw.rect(surface, theme.PANEL_BORDER, self.rect, width=1, border_radius=theme.RADIUS)
        f = theme.font(16)
        text = f.render(self.label, True, text_color)
        surface.blit(text, text.get_rect(center=self.rect.center))


class TabBar:
    def __init__(self, rect, labels, on_select=None, current=0):
        self.rect = pygame.Rect(rect)
        self.labels = labels
        self.on_select = on_select
        self.current = current
        self.enabled = [True] * len(labels)
        self._tab_rects = []
        self._layout()

    def _layout(self):
        n = len(self.labels)
        w = self.rect.width / n
        self._tab_rects = [
            pygame.Rect(int(self.rect.x + i * w), self.rect.y, int(w), self.rect.height)
            for i in range(n)
        ]

    def set_enabled(self, index, enabled):
        self.enabled[index] = enabled

    def handle_event(self, event) -> bool:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i, r in enumerate(self._tab_rects):
                if r.collidepoint(event.pos) and self.enabled[i]:
                    self.current = i
                    if self.on_select:
                        self.on_select(i)
                    return True
        return False

    def draw(self, surface):
        f = theme.font(16, bold=True)
        for i, (label, r) in enumerate(zip(self.labels, self._tab_rects)):
            if i == self.current:
                bg = theme.ACCENT_DARK
                fg = theme.TEXT
            elif not self.enabled[i]:
                bg = theme.BG
                fg = theme.TEXT_DIM
            else:
                bg = theme.PANEL_BG
                fg = theme.TEXT
            pygame.draw.rect(surface, bg, r)
            pygame.draw.rect(surface, theme.PANEL_BORDER, r, width=1)
            text = f.render(label, True, fg)
            surface.blit(text, text.get_rect(center=r.center))


class Table:
    ROW_H = 26
    HEADER_H = 30

    def __init__(self, rect, headers, weights=None):
        self.rect = pygame.Rect(rect)
        self.headers = headers
        self.weights = weights or [1] * len(headers)
        self.rows = []  # list of dict(cells=[...], style='normal'|'current'|'error'|'skip')
        self.scroll = 0

    def set_rows(self, rows):
        self.rows = rows

    def _col_rects(self):
        total_w = sum(self.weights)
        xs = []
        x = self.rect.x
        for w in self.weights:
            cw = int(self.rect.width * w / total_w)
            xs.append((x, cw))
            x += cw
        return xs

    def scroll_to(self, row_index):
        visible_rows = (self.rect.height - self.HEADER_H) // self.ROW_H
        top = self.scroll
        bottom = self.scroll + visible_rows
        if row_index < top:
            self.scroll = row_index
        elif row_index >= bottom:
            self.scroll = row_index - visible_rows + 1
        self.scroll = max(0, self.scroll)

    def handle_event(self, event) -> bool:
        if event.type == pygame.MOUSEWHEEL and self.rect.collidepoint(pygame.mouse.get_pos()):
            self.scroll = max(0, self.scroll - event.y * 2)
            max_scroll = max(0, len(self.rows) - 1)
            self.scroll = min(self.scroll, max_scroll)
            return True
        return False

    def draw(self, surface):
        pygame.draw.rect(surface, theme.PANEL_BG, self.rect, border_radius=theme.RADIUS)
        pygame.draw.rect(surface, theme.PANEL_BORDER, self.rect, width=1, border_radius=theme.RADIUS)
        cols = self._col_rects()
        f_head = theme.font(15, bold=True)
        f_row = theme.font(15)

        header_rect = pygame.Rect(self.rect.x, self.rect.y, self.rect.width, self.HEADER_H)
        pygame.draw.rect(surface, theme.BUTTON_BG, header_rect, border_top_left_radius=theme.RADIUS,
                          border_top_right_radius=theme.RADIUS)
        for (x, w), h in zip(cols, self.headers):
            text = f_head.render(h, True, theme.TEXT)
            surface.blit(text, (x + 8, self.rect.y + 6))

        clip = surface.get_clip()
        body_rect = pygame.Rect(self.rect.x, self.rect.y + self.HEADER_H, self.rect.width,
                                 self.rect.height - self.HEADER_H)
        surface.set_clip(body_rect)

        visible_rows = body_rect.height // self.ROW_H + 2
        for i in range(self.scroll, min(len(self.rows), self.scroll + visible_rows)):
            row = self.rows[i]
            ry = body_rect.y + (i - self.scroll) * self.ROW_H
            row_rect = pygame.Rect(self.rect.x, ry, self.rect.width, self.ROW_H)
            style = row.get("style", "normal")
            if style == "error":
                pygame.draw.rect(surface, theme.ERROR_BG, row_rect)
            elif style == "current":
                pygame.draw.rect(surface, theme.ROW_CURRENT, row_rect)
            elif i % 2 == 1:
                pygame.draw.rect(surface, theme.ROW_ALT, row_rect)

            fg = theme.ERROR_RED if style == "error" else (
                theme.SKIP_GRAY if style == "skip" else theme.TEXT)
            for (x, w), cell in zip(cols, row["cells"]):
                text = f_row.render(str(cell), True, fg)
                surface.blit(text, (x + 8, ry + 4))

        surface.set_clip(clip)


class TextBox:
    """Caja de texto simple. multiline=True permite varias líneas y salto
    con Enter; multiline=False dispara on_enter al presionar Enter."""

    def __init__(self, rect, text="", multiline=True, on_enter=None, placeholder=""):
        self.rect = pygame.Rect(rect)
        self.lines = text.split("\n") if text else [""]
        self.multiline = multiline
        self.on_enter = on_enter
        self.placeholder = placeholder
        self.focused = False
        self.cursor_row = 0
        self.cursor_col = 0
        self.scroll_line = 0
        self._cursor_visible = True
        self._blink_t = 0.0

    @property
    def text(self):
        return "\n".join(self.lines)

    @text.setter
    def text(self, value):
        self.lines = value.split("\n") if value else [""]
        self.cursor_row = min(self.cursor_row, len(self.lines) - 1)
        self.cursor_col = min(self.cursor_col, len(self.lines[self.cursor_row]))

    def _line_h(self):
        return theme.font(15).get_height() + 4

    def handle_event(self, event) -> bool:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            inside = self.rect.collidepoint(event.pos)
            self.focused = inside
            if inside:
                self._place_cursor(event.pos)
            return inside

        if not self.focused:
            return False

        if event.type == pygame.TEXTINPUT:
            self._insert(event.text)
            return True

        if event.type == pygame.KEYDOWN:
            line = self.lines[self.cursor_row]
            if event.key == pygame.K_BACKSPACE:
                if self.cursor_col > 0:
                    self.lines[self.cursor_row] = line[:self.cursor_col - 1] + line[self.cursor_col:]
                    self.cursor_col -= 1
                elif self.cursor_row > 0:
                    prev = self.lines[self.cursor_row - 1]
                    self.cursor_col = len(prev)
                    self.lines[self.cursor_row - 1] = prev + line
                    del self.lines[self.cursor_row]
                    self.cursor_row -= 1
            elif event.key == pygame.K_DELETE:
                if self.cursor_col < len(line):
                    self.lines[self.cursor_row] = line[:self.cursor_col] + line[self.cursor_col + 1:]
                elif self.cursor_row < len(self.lines) - 1:
                    self.lines[self.cursor_row] = line + self.lines[self.cursor_row + 1]
                    del self.lines[self.cursor_row + 1]
            elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                if self.multiline:
                    self.lines.insert(self.cursor_row + 1, line[self.cursor_col:])
                    self.lines[self.cursor_row] = line[:self.cursor_col]
                    self.cursor_row += 1
                    self.cursor_col = 0
                elif self.on_enter:
                    self.on_enter()
            elif event.key == pygame.K_LEFT:
                if self.cursor_col > 0:
                    self.cursor_col -= 1
                elif self.cursor_row > 0:
                    self.cursor_row -= 1
                    self.cursor_col = len(self.lines[self.cursor_row])
            elif event.key == pygame.K_RIGHT:
                if self.cursor_col < len(line):
                    self.cursor_col += 1
                elif self.cursor_row < len(self.lines) - 1:
                    self.cursor_row += 1
                    self.cursor_col = 0
            elif event.key == pygame.K_UP and self.multiline:
                if self.cursor_row > 0:
                    self.cursor_row -= 1
                    self.cursor_col = min(self.cursor_col, len(self.lines[self.cursor_row]))
            elif event.key == pygame.K_DOWN and self.multiline:
                if self.cursor_row < len(self.lines) - 1:
                    self.cursor_row += 1
                    self.cursor_col = min(self.cursor_col, len(self.lines[self.cursor_row]))
            elif event.key == pygame.K_HOME:
                self.cursor_col = 0
            elif event.key == pygame.K_END:
                self.cursor_col = len(line)
            elif event.key == pygame.K_TAB:
                self._insert("  ")
            else:
                return True
            self._ensure_visible()
            return True
        return False

    def _insert(self, text):
        if not self.multiline:
            text = text.replace("\n", "")
        for ch in text:
            if ch == "\n":
                line = self.lines[self.cursor_row]
                self.lines.insert(self.cursor_row + 1, line[self.cursor_col:])
                self.lines[self.cursor_row] = line[:self.cursor_col]
                self.cursor_row += 1
                self.cursor_col = 0
            else:
                line = self.lines[self.cursor_row]
                self.lines[self.cursor_row] = line[:self.cursor_col] + ch + line[self.cursor_col:]
                self.cursor_col += 1
        self._ensure_visible()

    def _place_cursor(self, pos):
        f = theme.font(15)
        lh = self._line_h()
        rel_y = pos[1] - self.rect.y - 4
        row = self.scroll_line + max(0, rel_y // lh)
        row = min(row, len(self.lines) - 1)
        self.cursor_row = row
        line = self.lines[row]
        rel_x = pos[0] - self.rect.x - 6
        col = len(line)
        for i in range(len(line) + 1):
            if f.size(line[:i])[0] >= rel_x:
                col = i
                break
        self.cursor_col = col

    def _ensure_visible(self):
        visible = max(1, (self.rect.height - 8) // self._line_h())
        if self.cursor_row < self.scroll_line:
            self.scroll_line = self.cursor_row
        elif self.cursor_row >= self.scroll_line + visible:
            self.scroll_line = self.cursor_row - visible + 1

    def update(self, dt):
        self._blink_t += dt
        if self._blink_t > 0.5:
            self._blink_t = 0
            self._cursor_visible = not self._cursor_visible

    def draw(self, surface):
        pygame.draw.rect(surface, theme.PANEL_BG, self.rect, border_radius=theme.RADIUS)
        border_color = theme.ACCENT if self.focused else theme.PANEL_BORDER
        pygame.draw.rect(surface, border_color, self.rect, width=1, border_radius=theme.RADIUS)

        f = theme.font(15)
        lh = self._line_h()
        clip = surface.get_clip()
        surface.set_clip(self.rect)

        if self.text == "" and not self.focused and self.placeholder:
            ph = f.render(self.placeholder, True, theme.TEXT_DIM)
            surface.blit(ph, (self.rect.x + 6, self.rect.y + 4))
        else:
            visible = max(1, (self.rect.height - 8) // lh)
            for i in range(self.scroll_line, min(len(self.lines), self.scroll_line + visible + 1)):
                text = f.render(self.lines[i], True, theme.TEXT)
                surface.blit(text, (self.rect.x + 6, self.rect.y + 4 + (i - self.scroll_line) * lh))

            if self.focused and self._cursor_visible:
                row = self.cursor_row - self.scroll_line
                line = self.lines[self.cursor_row]
                cx = self.rect.x + 6 + f.size(line[:self.cursor_col])[0]
                cy = self.rect.y + 4 + row * lh
                pygame.draw.line(surface, theme.CURSOR, (cx, cy), (cx, cy + lh - 4), 1)

        surface.set_clip(clip)


class Slider:
    def __init__(self, rect, min_val, max_val, value):
        self.rect = pygame.Rect(rect)
        self.min_val = min_val
        self.max_val = max_val
        self.value = value
        self.dragging = False

    def _handle_x(self):
        t = (self.value - self.min_val) / (self.max_val - self.min_val)
        return self.rect.x + int(t * self.rect.width)

    def handle_event(self, event) -> bool:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            handle_rect = pygame.Rect(self._handle_x() - 6, self.rect.y - 4, 12, self.rect.height + 8)
            if handle_rect.collidepoint(event.pos) or self.rect.collidepoint(event.pos):
                self.dragging = True
                self._set_from_x(event.pos[0])
                return True
        elif event.type == pygame.MOUSEBUTTONUP:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            self._set_from_x(event.pos[0])
            return True
        return False

    def _set_from_x(self, x):
        t = max(0.0, min(1.0, (x - self.rect.x) / self.rect.width))
        self.value = self.min_val + t * (self.max_val - self.min_val)

    def draw(self, surface):
        mid_y = self.rect.centery
        pygame.draw.line(surface, theme.PANEL_BORDER, (self.rect.x, mid_y), (self.rect.right, mid_y), 3)
        t = (self.value - self.min_val) / (self.max_val - self.min_val)
        filled_x = self.rect.x + int(t * self.rect.width)
        pygame.draw.line(surface, theme.ACCENT, (self.rect.x, mid_y), (filled_x, mid_y), 3)
        pygame.draw.circle(surface, theme.ACCENT, (self._handle_x(), mid_y), 7)


class NavBar:
    """Barra reutilizable: reiniciar / anterior / play-pausa / siguiente +
    slider de velocidad, ligada directamente a un StepPlayer."""

    def __init__(self, rect, player):
        self.rect = pygame.Rect(rect)
        self.player = player
        x = self.rect.x
        h = self.rect.height
        y = self.rect.y
        self.btn_reset = Button((x, y, 50, h), "|<<", self._on_reset)
        x += 58
        self.btn_prev = Button((x, y, 74, h), "< Ant", self._on_prev)
        x += 82
        self.btn_play = Button((x, y, 90, h), "Play", self._on_play)
        x += 98
        self.btn_next = Button((x, y, 74, h), "Sig >", self._on_next)
        x += 88
        self.slider = Slider((x, y + h // 2 - 2, 140, 4), 0.5, 5.0, player.speed)
        x += 158
        self.label_x = x

    def _on_reset(self):
        self.player.go_start()

    def _on_prev(self):
        self.player.prev()

    def _on_play(self):
        self.player.toggle_play()

    def _on_next(self):
        self.player.next()

    def handle_event(self, event) -> bool:
        consumed = False
        for w in (self.btn_reset, self.btn_prev, self.btn_play, self.btn_next):
            if w.handle_event(event):
                consumed = True
        if self.slider.handle_event(event):
            self.player.speed = self.slider.value
            consumed = True
        return consumed

    def draw(self, surface):
        self.btn_play.label = "Pausa" if self.player.playing else "Play"
        self.btn_prev.enabled = self.player.index > 0
        self.btn_next.enabled = self.player.index < self.player.max_index
        for w in (self.btn_reset, self.btn_prev, self.btn_play, self.btn_next):
            w.draw(surface)
        self.slider.value = self.player.speed
        self.slider.draw(surface)
        f = theme.font(14)
        total = self.player.max_index + 1
        txt = f.render(
            f"Velocidad: {self.player.speed:.1f} pasos/s   Paso {self.player.index + 1}/{total}",
            True, theme.TEXT_DIM,
        )
        surface.blit(txt, (self.label_x + 10, self.rect.y + (self.rect.height - txt.get_height()) // 2))
