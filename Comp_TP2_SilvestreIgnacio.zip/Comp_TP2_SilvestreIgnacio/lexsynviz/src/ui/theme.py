"""Paleta de colores, fuentes y medidas compartidas por toda la UI."""
import pygame

BG = (24, 26, 32)
PANEL_BG = (32, 35, 43)
PANEL_BORDER = (56, 60, 72)
TEXT = (230, 232, 238)
TEXT_DIM = (150, 155, 168)
ACCENT = (86, 156, 255)
ACCENT_DARK = (52, 96, 168)
OK_GREEN = (94, 201, 133)
ERROR_RED = (232, 93, 93)
ERROR_BG = (63, 32, 34)
SKIP_GRAY = (100, 104, 116)
ROW_ALT = (38, 41, 50)
ROW_CURRENT = (40, 60, 92)
BUTTON_BG = (46, 50, 61)
BUTTON_HOVER = (60, 65, 79)
BUTTON_DISABLED = (38, 40, 47)
CURSOR = (230, 232, 238)

FONT_NAME = None  # fuente por defecto del sistema
_fonts = {}


def font(size: int, bold: bool = False):
    key = (size, bold)
    if key not in _fonts:
        f = pygame.font.SysFont(FONT_NAME or "dejavusansmono,consolas,monospace", size, bold=bold)
        _fonts[key] = f
    return _fonts[key]


PAD = 10
RADIUS = 6
