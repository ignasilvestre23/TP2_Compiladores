"""Árbol de derivación: nodos + layout simple para dibujar en pygame."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class TreeNode:
    symbol: str
    step_created: int
    is_terminal: bool
    children: list = field(default_factory=list)
    x: float = 0.0
    y: float = 0.0
    subtree_width: float = 1.0
    value: str | None = None  # lexema real consumido (se completa al hacer MATCH)


def compute_layout(root: TreeNode, x_gap: float = 1.0, y_gap: float = 1.0) -> None:
    """Asigna x,y a cada nodo. x,y quedan en 'unidades' (0,1,2,...);
    el llamador las escala a píxeles."""

    def layout(node: TreeNode, depth: int) -> float:
        node.y = depth * y_gap
        if not node.children:
            node.subtree_width = x_gap
            return node.subtree_width
        total = 0.0
        for child in node.children:
            total += layout(child, depth + 1)
        node.subtree_width = max(total, x_gap)
        return node.subtree_width

    def assign_x(node: TreeNode, left: float) -> None:
        if not node.children:
            node.x = left + node.subtree_width / 2
            return
        cursor = left
        for child in node.children:
            assign_x(child, cursor)
            cursor += child.subtree_width
        first_child = node.children[0]
        last_child = node.children[-1]
        node.x = (first_child.x + last_child.x) / 2

    layout(root, 0)
    assign_x(root, 0.0)


def visible_nodes(root: TreeNode, up_to_step: int):
    """Devuelve la lista de nodos creados en pasos <= up_to_step, junto con
    sus aristas visibles (padre, hijo), recorriendo en pre-orden."""
    nodes = []
    edges = []

    def walk(node: TreeNode, parent):
        if node.step_created > up_to_step:
            return
        nodes.append(node)
        if parent is not None:
            edges.append((parent, node))
        for child in node.children:
            walk(child, node)

    walk(root, None)
    return nodes, edges
