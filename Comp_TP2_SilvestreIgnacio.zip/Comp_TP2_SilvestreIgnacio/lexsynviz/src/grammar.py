"""Gramática libre de contexto: parseo BNF, transformación a LL(1)
(eliminación de recursión izquierda + factorización izquierda),
cálculo de FIRST/FOLLOW y construcción de la tabla predictiva LL(1).
"""
from __future__ import annotations

from dataclasses import dataclass, field

EPS = "ε"       # símbolo épsilon, solo para mostrar en FIRST/FOLLOW
END = "$"       # marcador de fin de cadena


class GrammarError(Exception):
    pass


Production = tuple  # tupla de símbolos; () representa producción vacía (epsilon)


@dataclass
class Grammar:
    start: str
    productions: dict  # nonterminal -> list[Production]
    terminals: set
    nonterminals: list  # orden de aparición

    def alt_to_str(self, alt: Production) -> str:
        return " ".join(alt) if alt else EPS

    def production_to_str(self, nt: str, alt: Production) -> str:
        return f"{nt} -> {self.alt_to_str(alt)}"


def parse_bnf(text: str, known_terminals: set) -> Grammar:
    productions: dict = {}
    order: list = []
    start = None

    for lineno, raw in enumerate(text.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "->" not in line:
            raise GrammarError(f"Línea {lineno}: falta '->' en la regla: {raw!r}")
        lhs, rhs = line.split("->", 1)
        lhs = lhs.strip()
        if not lhs:
            raise GrammarError(f"Línea {lineno}: no-terminal vacío antes de '->'")
        if start is None:
            start = lhs
        if lhs not in productions:
            productions[lhs] = []
            order.append(lhs)
        for alt_text in rhs.split("|"):
            symbols = alt_text.strip().split()
            if symbols in ([], ["eps"], ["ε"]) or (len(symbols) == 1 and symbols[0] in ("eps", "ε")):
                alt: Production = tuple()
            else:
                alt = tuple(symbols)
            productions[lhs].append(alt)

    if start is None:
        raise GrammarError("La gramática está vacía")

    nonterminal_names = set(productions.keys())
    used_terminals: set = set()
    for nt, alts in productions.items():
        for alt in alts:
            for sym in alt:
                if sym in nonterminal_names:
                    continue
                used_terminals.add(sym)
                if sym not in known_terminals:
                    raise GrammarError(
                        f"El símbolo '{sym}' usado en la producción de '{nt}' no es un "
                        f"no-terminal definido ni un token del léxico"
                    )

    return Grammar(start=start, productions=productions, terminals=used_terminals, nonterminals=order)


def _fresh_name(base: str, taken: set) -> str:
    candidate = base + "'"
    while candidate in taken:
        candidate += "'"
    taken.add(candidate)
    return candidate


def eliminate_left_recursion(grammar: Grammar) -> Grammar:
    nts = list(grammar.nonterminals)
    prods = {nt: list(alts) for nt, alts in grammar.productions.items()}
    taken_names = set(nts)
    order = list(nts)

    for i, ai in enumerate(nts):
        for aj in nts[:i]:
            new_alts = []
            for alt in prods[ai]:
                if alt and alt[0] == aj:
                    rest = alt[1:]
                    for aj_alt in prods[aj]:
                        new_alts.append(tuple(aj_alt) + rest)
                else:
                    new_alts.append(alt)
            prods[ai] = new_alts

        # eliminar recursión izquierda inmediata en ai
        recursive = [alt for alt in prods[ai] if alt and alt[0] == ai]
        non_recursive = [alt for alt in prods[ai] if not (alt and alt[0] == ai)]
        if recursive:
            ai_new = _fresh_name(ai, taken_names)
            order.append(ai_new)
            prods[ai] = [beta + (ai_new,) if beta else (ai_new,) for beta in non_recursive]
            prods[ai_new] = [alpha[1:] + (ai_new,) for alpha in recursive]
            prods[ai_new].append(tuple())

    return Grammar(start=grammar.start, productions=prods, terminals=grammar.terminals, nonterminals=order)


def _common_prefix_len(a: Production, b: Production) -> int:
    n = 0
    for x, y in zip(a, b):
        if x != y:
            break
        n += 1
    return n


def left_factor(grammar: Grammar) -> Grammar:
    prods = {nt: list(alts) for nt, alts in grammar.productions.items()}
    order = list(grammar.nonterminals)
    taken_names = set(order)

    changed = True
    guard = 0
    while changed and guard < 50:
        changed = False
        guard += 1
        for nt in list(prods.keys()):
            alts = prods[nt]
            if len(alts) < 2:
                continue
            best_prefix_len = 0
            best_prefix = None
            for a in range(len(alts)):
                for b in range(a + 1, len(alts)):
                    l = _common_prefix_len(alts[a], alts[b])
                    if l > 0 and l > best_prefix_len:
                        best_prefix_len = l
                        best_prefix = alts[a][:l]
            if best_prefix is None:
                continue
            grouped = [alt for alt in alts if alt[:best_prefix_len] == best_prefix]
            ungrouped = [alt for alt in alts if alt[:best_prefix_len] != best_prefix]
            new_nt = _fresh_name(nt, taken_names)
            order.append(new_nt)
            prods[new_nt] = [alt[best_prefix_len:] for alt in grouped]
            prods[nt] = ungrouped + [best_prefix + (new_nt,)]
            changed = True

    return Grammar(start=grammar.start, productions=prods, terminals=grammar.terminals, nonterminals=order)


def to_ll1_ready(grammar: Grammar) -> Grammar:
    return left_factor(eliminate_left_recursion(grammar))


def compute_first_sets(grammar: Grammar) -> dict:
    first = {nt: set() for nt in grammar.productions}
    for t in grammar.terminals:
        first[t] = {t}

    def first_of_sequence(seq: Production) -> set:
        result = set()
        if not seq:
            result.add(EPS)
            return result
        for sym in seq:
            sym_first = first.get(sym, {sym})
            result |= (sym_first - {EPS})
            if EPS not in sym_first:
                break
        else:
            result.add(EPS)
        return result

    changed = True
    while changed:
        changed = False
        for nt, alts in grammar.productions.items():
            for alt in alts:
                added = first_of_sequence(alt) - first[nt]
                if added:
                    first[nt] |= added
                    changed = True
    return first


def compute_follow_sets(grammar: Grammar, first: dict) -> dict:
    follow = {nt: set() for nt in grammar.productions}
    follow[grammar.start].add(END)

    def first_of_sequence(seq: Production) -> set:
        result = set()
        if not seq:
            result.add(EPS)
            return result
        for sym in seq:
            sym_first = first.get(sym, {sym})
            result |= (sym_first - {EPS})
            if EPS not in sym_first:
                break
        else:
            result.add(EPS)
        return result

    changed = True
    while changed:
        changed = False
        for nt, alts in grammar.productions.items():
            for alt in alts:
                for i, sym in enumerate(alt):
                    if sym not in grammar.productions:
                        continue
                    beta = alt[i + 1:]
                    beta_first = first_of_sequence(beta)
                    added = beta_first - {EPS}
                    if added - follow[sym]:
                        follow[sym] |= added
                        changed = True
                    if EPS in beta_first:
                        added2 = follow[nt] - follow[sym]
                        if added2:
                            follow[sym] |= added2
                            changed = True
    return follow


@dataclass
class LL1Conflict:
    nonterminal: str
    terminal: str
    existing: Production
    new: Production


@dataclass
class LL1Table:
    grammar: Grammar
    first: dict
    follow: dict
    table: dict  # (nt, terminal) -> Production
    conflicts: list


def build_ll1_table(grammar: Grammar) -> LL1Table:
    first = compute_first_sets(grammar)
    follow = compute_follow_sets(grammar, first)
    table: dict = {}
    conflicts: list = []

    def first_of_sequence(seq: Production) -> set:
        result = set()
        if not seq:
            result.add(EPS)
            return result
        for sym in seq:
            sym_first = first.get(sym, {sym})
            result |= (sym_first - {EPS})
            if EPS not in sym_first:
                break
        else:
            result.add(EPS)
        return result

    for nt, alts in grammar.productions.items():
        for alt in alts:
            alt_first = first_of_sequence(alt)
            for a in alt_first - {EPS}:
                key = (nt, a)
                if key in table and table[key] != alt:
                    conflicts.append(LL1Conflict(nt, a, table[key], alt))
                else:
                    table[key] = alt
            if EPS in alt_first:
                for b in follow[nt]:
                    key = (nt, b)
                    if key in table and table[key] != alt:
                        conflicts.append(LL1Conflict(nt, b, table[key], alt))
                    else:
                        table[key] = alt

    return LL1Table(grammar=grammar, first=first, follow=follow, table=table, conflicts=conflicts)
