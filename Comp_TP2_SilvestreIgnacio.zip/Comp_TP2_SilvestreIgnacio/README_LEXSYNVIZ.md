# TP2 - Analizador Sintáctico con LexSynViz

## Descripción

Este trabajo contiene el análisis léxico y sintáctico de **10 ejercicios**
utilizando el analizador **LexSynViz**, una herramienta de visualización
para análisis léxico (maximal munch) y análisis sintáctico LL(1).

Para cada ejercicio se completó primero la producción faltante de la
gramática, se realizó el análisis **manualmente**, y luego se comprobó el
resultado cargando los archivos `.lex`/`.gram` en LexSynViz.

## Archivos incluidos

| Ejercicio | Léxico | Gramática | Cadena(s) de prueba |
|---|---|---|---|
| 1. Identificadores | `01_identificadores.lex` | `01_identificadores.gram` | `nombre` |
| 2. Asignación | `02_asignacion.lex` | `02_asignacion.gram` | `edad = 25` |
| 3. Suma | `03_suma.lex` | `03_suma.gram` | `10 + 20` |
| 4. Suma y resta | `04_suma_resta.lex` | `04_suma_resta.gram` | `20 - 5 + 10` |
| 5. Precedencia de operadores | `05_precedencia.lex` | `05_precedencia.gram` | `10 + 20 * 30` |
| 6. Operaciones aritméticas | `06_aritmeticas.lex` | `06_aritmeticas.gram` | `100 - 20 / 5` |
| 7. Paréntesis | `07_parentesis.lex` | `07_parentesis.gram` | `(10 + 20) * 5` |
| 8. Identificadores y números | `08_id_numeros.lex` | `08_id_numeros.gram` | `id + id * id` |
| 9. Expresiones complejas | `09_expresiones_complejas.lex` | `09_expresiones_complejas.gram` | `a + b * c` / `(a + b) * c` / `a * (b + c)` / `a + b * (c - 5)` |
| 10. Integrador | `10_integrador.lex` | `10_integrador.gram` | `resultado = a + b * (c - 10)` (+ 2 cadenas con error) |

Las cadenas de cada ejercicio también están en `examples/`, listas para
cargar desde los botones de "Entrada" de la app.

### Documento principal
- **TP2_Analizador_Sintactico_COMPLETO.docx**: análisis completo de los 10
  ejercicios, con reglas léxicas, gramática BNF completada, símbolo de
  arranque, terminales, no terminales, producciones, tokens, derivación,
  árbol de derivación, conclusión y justificación de cada uno.

---

## Ejercicio 1: Identificadores

**Reglas léxicas**
```
ID = [a-zA-Z_][a-zA-Z_0-9]*
SKIP: WS = \s+
```

**Gramática BNF**
```
S -> ID
```

**Entrada:** `nombre`

- Tokens: `[ID(nombre)]`
- No terminales: `S` — Terminales: `ID`
- Derivación: `S ⇒ ID ⇒ nombre`
- Árbol:
  ```
        S
        |
    ID(nombre)
  ```
- Conclusión: ✓ pertenece al lenguaje.

## Ejercicio 2: Asignación

**Reglas léxicas**
```
ID = [a-zA-Z_][a-zA-Z_0-9]*
NUM = [0-9]+
ASIG = =
SKIP: WS = \s+
```

**Gramática BNF**
```
S -> ID ASIG NUM
```

**Entrada:** `edad = 25`

- Tokens: `[ID(edad), ASIG(=), NUM(25)]`
- No terminales: `S` — Terminales: `ID, ASIG, NUM`
- Derivación: `S ⇒ ID ASIG NUM ⇒ edad = 25`
- Árbol:
  ```
           S
        /  |  \
      ID  ASIG NUM
      |    |    |
    edad   =   25
  ```
- Conclusión: ✓ pertenece al lenguaje.

## Ejercicio 3: Suma

**Reglas léxicas**
```
NUM = [0-9]+
SUMA = \+
SKIP: WS = \s+
```

**Gramática BNF** (producción a completar: `E -> E SUMA ______ | NUM`)
```
E -> E SUMA NUM | NUM
```
> Se completa con `NUM`, no con un no terminal nuevo, porque la gramática
> no define ningún otro símbolo.

**Entrada:** `10 + 20`

- Tokens: `[NUM(10), SUMA(+), NUM(20)]`
- No terminales: `E` — Terminales: `NUM, SUMA`
- Derivación: `E ⇒ E SUMA NUM ⇒ NUM SUMA NUM ⇒ 10 SUMA 20`
- Árbol:
  ```
        E
      / | \
     E SUMA NUM
     |        |
    NUM      20
     |
    10
  ```
- Nota: `E -> E SUMA NUM` es recursiva a izquierda; LexSynViz la
  transforma automáticamente para construir la tabla LL(1).
- Conclusión: ✓ pertenece al lenguaje.

## Ejercicio 4: Suma y resta

**Reglas léxicas**
```
NUM = [0-9]+
SUMA = \+
RESTA = \-
SKIP: WS = \s+
```

**Gramática BNF** (producción a completar: `E -> E SUMA T | E RESTA T | ______`)
```
E -> E SUMA T | E RESTA T | T
T -> NUM
```
> Se completa con `T`: es el caso base que corta la recursión izquierda.

**Entrada:** `20 - 5 + 10`

- Tokens: `[NUM(20), RESTA(-), NUM(5), SUMA(+), NUM(10)]`
- No terminales: `E, T` — Terminales: `NUM, SUMA, RESTA`
- Derivación: `E ⇒ E SUMA T ⇒ E RESTA T SUMA T ⇒ ... ⇒ 20 RESTA 5 SUMA 10`
- Árbol: asociado a izquierda — primero `(20 - 5)`, luego `+ 10`.
- Conclusión: ✓ pertenece al lenguaje.

## Ejercicio 5: Precedencia de operadores

**Reglas léxicas**
```
NUM = [0-9]+
SUMA = \+
MULT = \*
SKIP: WS = \s+
```

**Gramática BNF** (producción a completar: `T -> T MULT F | ______`)
```
E -> E SUMA T | T
T -> T MULT F | F
F -> NUM
```
> Se completa con `F`: caso base de `T`, igual que `T` lo es de `E`.

**Entrada:** `10 + 20 * 30`

- Tokens: `[NUM(10), SUMA(+), NUM(20), MULT(*), NUM(30)]`
- No terminales: `E, T, F` — Terminales: `NUM, SUMA, MULT`
- Derivación: `E ⇒ E SUMA T ⇒ ... ⇒ 10 SUMA 20 MULT 30`
- En el árbol: cada `NUM` aislado es un `F`; el subárbol `20 * 30`
  completo es un `T`; todo el árbol (con raíz en la suma) es `E`.
- La jerarquía E/T/F obliga a que las multiplicaciones (T) queden
  siempre más "adentro" del árbol que las sumas (E), lo que codifica la
  precedencia sin reglas adicionales ni paréntesis.
- Conclusión: ✓ pertenece al lenguaje.

## Ejercicio 6: Operaciones aritméticas

**Reglas léxicas**
```
NUM = [0-9]+
SUMA = \+
RESTA = \-
MULT = \*
DIV = /
SKIP: WS = \s+
```

**Gramática BNF** (producción a completar: `F -> ______`)
```
E -> E SUMA T | E RESTA T | T
T -> T MULT F | T DIV F | F
F -> NUM
```

**Entrada:** `100 - 20 / 5`

- Tokens: `[NUM(100), RESTA(-), NUM(20), DIV(/), NUM(5)]`
- No terminales: `E, T, F` — Terminales: `NUM, SUMA, RESTA, MULT, DIV`
- Derivación: `E ⇒ E RESTA T ⇒ ... ⇒ 100 RESTA 20 DIV 5`
- **Pregunta:** ¿qué diferencia suma/resta de mult/división? Los niveles
  `E` y `T`: `E` solo maneja SUMA/RESTA y usa `T` como operando; `T` solo
  maneja MULT/DIV y usa `F`. Como `T` se anida dentro de `E`, toda
  multiplicación/división se resuelve como unidad antes de sumar/restar.
- Conclusión: ✓ pertenece al lenguaje.

## Ejercicio 7: Paréntesis

**Reglas léxicas**
```
NUM = [0-9]+
SUMA = \+
MULT = \*
LPAREN = \(
RPAREN = \)
SKIP: WS = \s+
```

**Gramática BNF** (producción a completar: `F -> LPAREN E RPAREN | ______`)
```
E -> E SUMA T | T
T -> T MULT F | F
F -> LPAREN E RPAREN | NUM
```

**Entrada:** `(10 + 20) * 5`

- Tokens: `[LPAREN, NUM(10), SUMA, NUM(20), RPAREN, MULT, NUM(5)]`
- No terminales: `E, T, F` — Terminales: `NUM, SUMA, MULT, LPAREN, RPAREN`
- Derivación: `E ⇒ T ⇒ T MULT F ⇒ F MULT F ⇒ (E) MULT F ⇒ ... ⇒ (10 + 20) * 5`
- El paréntesis convierte `10 + 20` en un único `F`, por eso puede
  multiplicarse por 5 como si fuera un solo operando.
- Conclusión: ✓ pertenece al lenguaje.

## Ejercicio 8: Identificadores y números

**Reglas léxicas**
```
NUM = [0-9]+
ID = [a-zA-Z_][a-zA-Z_0-9]*
SUMA = \+
RESTA = \-
MULT = \*
DIV = /
LPAREN = \(
RPAREN = \)
SKIP: WS = \s+
```

**Gramática BNF** (producción a completar: `F -> LPAREN E RPAREN | ______`)
```
E -> E SUMA T | E RESTA T | T
T -> T MULT F | T DIV F | F
F -> LPAREN E RPAREN | ID | NUM
```

**Entrada:** `id + id * id`

- Tokens: `[ID(id), SUMA(+), ID(id), MULT(*), ID(id)]`
- No terminales: `E, T, F` — Terminales: `NUM, ID, SUMA, RESTA, MULT, DIV, LPAREN, RPAREN`
- Derivación: `E ⇒ E SUMA T ⇒ ... ⇒ id SUMA id MULT id`
- **Pregunta:** ¿por qué ID es terminal? Porque lo reconoce directamente
  el analizador léxico (una expresión regular), es un token indivisible
  para la gramática y nunca aparece del lado izquierdo de una producción.
- Conclusión: ✓ pertenece al lenguaje.

## Ejercicio 9: Expresiones complejas

**Reglas léxicas y gramática** (ya completa, igual a la del ejercicio 8)
```
E -> E SUMA T | E RESTA T | T
T -> T MULT F | T DIV F | F
F -> LPAREN E RPAREN | ID | NUM
```

Se analizan 4 cadenas:

| Cadena | Tokens | Resultado |
|---|---|---|
| `a + b * c` | ID, SUMA, ID, MULT, ID | ✓ pertenece — raíz del árbol: SUMA |
| `(a + b) * c` | LPAREN, ID, SUMA, ID, RPAREN, MULT, ID | ✓ pertenece — raíz del árbol: MULT |
| `a * (b + c)` | ID, MULT, LPAREN, ID, SUMA, ID, RPAREN | ✓ pertenece — raíz del árbol: MULT |
| `a + b * (c - 5)` | ID, SUMA, ID, MULT, LPAREN, ID, RESTA, NUM, RPAREN | ✓ pertenece — raíz del árbol: SUMA |

- **Pregunta:** comparar `a + b * c` vs `(a + b) * c`. Sin paréntesis, la
  raíz del árbol es la SUMA (E) y la multiplicación queda más profunda
  (T), por la precedencia normal de la gramática. Con paréntesis, `a + b`
  se reduce primero a un único `F`, y por eso la raíz pasa a ser la
  MULTIPLICACIÓN: los paréntesis invierten qué operador queda arriba.

## Ejercicio 10: Integrador

**Reglas léxicas**
```
NUM = [0-9]+
ID = [a-zA-Z_][a-zA-Z_0-9]*
SUMA = \+
RESTA = \-
MULT = \*
DIV = /
LPAREN = \(
RPAREN = \)
ASIG = =
SKIP: WS = \s+
```

**Gramática BNF** (producción a completar: `S -> ______`)
```
S -> ID ASIG E
E -> E SUMA T | E RESTA T | T
T -> T MULT F | T DIV F | F
F -> LPAREN E RPAREN | ID | NUM
```
> Se completa con `ID ASIG E`: una asignación es un identificador, `=`,
> y una expresión aritmética completa.

**Cadena 1 (válida):** `resultado = a + b * (c - 10)`
- Tokens: `[ID(resultado), ASIG(=), ID(a), SUMA(+), ID(b), MULT(*), LPAREN, ID(c), RESTA(-), NUM(10), RPAREN]`
- Derivación: `S ⇒ ID ASIG E ⇒ resultado = E SUMA T ⇒ ... ⇒ resultado = a SUMA b MULT (c RESTA 10)`
- Conclusión: ✓ pertenece al lenguaje.

**Cadena 2 (con error):** `resultado = a + * b`
- Tokens (sin error léxico): `[ID(resultado), ASIG(=), ID(a), SUMA(+), MULT(*), ID(b)]`
- Falla justo después de `SUMA (+)`: la producción `T -> T MULT F | T DIV F | F`
  necesita que `T` empiece con `ID`, `NUM` o `LPAREN`, pero el siguiente
  token es `MULT`.
- Esperaba: `ID`, `NUM` o `LPAREN`. Encontró: `MULT`.
- Conclusión: ✗ NO pertenece — falta un operando entre `+` y `*`.

**Cadena 3 (con error):** `resultado = (a + b`
- Tokens (sin error léxico): `[ID(resultado), ASIG(=), LPAREN, ID(a), SUMA(+), ID(b)]`
- La derivación reconoce `(a + b` como una `E` completa dentro de
  `F -> LPAREN E RPAREN`, pero la entrada termina ahí.
- Esperaba: `RPAREN`. Encontró: fin de la cadena.
- Conclusión: ✗ NO pertenece — el paréntesis abierto nunca se cierra.

---

## Cómo usar en LexSynViz

### Instalación
```bash
python3 -m venv .venv
.venv\Scripts\Activate.ps1      # Windows
# source .venv/bin/activate     # Linux/macOS
pip install -r requirements.txt
```

### Ejecución
```bash
python main.py
```

### Cómo cargar cada ejercicio
1. En la pestaña **Configuración**, seleccioná todo el contenido del
   recuadro **Gramática (BNF)** (`Ctrl+A`) y pegá el contenido del
   `.gram` del ejercicio. Hacé lo mismo en **Reglas léxicas (regex)**
   con el `.lex` correspondiente. (Los botones de "Entrada" de abajo
   solo cargan la cadena de prueba, no la gramática ni el léxico —
   esos dos recuadros hay que completarlos a mano cada vez.)
2. Escribí la cadena de entrada del ejercicio (o hacé clic en su botón
   de "Entrada: ...").
3. Presioná **Analizar**.
4. Recorré las pestañas:
   - **Léxico**: tokens reconocidos paso a paso (maximal munch).
   - **Sintáctico**: pila / entrada restante / acción del algoritmo LL(1).
   - **Árbol**: árbol de derivación, sincronizado con el paso sintáctico.
5. Para el ejercicio 10, probá primero la cadena válida y luego las dos
   cadenas con error para ver en vivo dónde el parser las rechaza.

## Conclusión

Los 10 ejercicios fueron analizados primero manualmente (gramática
completada, símbolos, producciones, tokens, derivación y árbol) y luego
verificados con LexSynViz como herramienta de comprobación. En todos los
casos el análisis léxico reconoce correctamente los tokens definidos, la
gramática es válida (o transformable a LL(1) cuando tiene recursión
izquierda), y las conclusiones de pertenencia/no pertenencia al lenguaje
coinciden con lo obtenido manualmente.

---
**Nota**: Este trabajo fue realizado siguiendo las consignas
especificadas en el enunciado del TP2 (`Comp_TP2.docx`).
