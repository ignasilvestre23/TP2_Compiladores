"""Analizador léxico: reglas basadas en regex, estrategia de 'maximal munch'.

Cada regla del archivo .lex se compila a una regex anclada al inicio.
En cada posición del texto se prueban TODAS las reglas y se elige la que
produce el lexema más largo; en caso de empate gana la que aparece antes
en el archivo (mismo criterio que usan herramientas como flex).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field


class LexRuleError(Exception):
    pass


@dataclass
class LexRule:
    name: str
    pattern: str
    skip: bool
    compiled: re.Pattern = field(repr=False)


@dataclass
class LexStep:
    index: int
    start: int
    end: int
    lexeme: str
    token_type: str  # nombre de la regla, "ERROR" o "EOF"
    skipped: bool
    ok: bool
    message: str


@dataclass
class Token:
    type: str
    lexeme: str
    start: int
    end: int


@dataclass
class LexResult:
    steps: list[LexStep]
    tokens: list[Token]
    has_errors: bool
    source: str


def parse_lex_rules(text: str) -> list[LexRule]:
    rules: list[LexRule] = []
    for lineno, raw in enumerate(text.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        skip = False
        if line.startswith("SKIP:"):
            skip = True
            line = line[len("SKIP:"):].strip()
        if "=" not in line:
            raise LexRuleError(f"Línea {lineno}: falta '=' en la regla léxica: {raw!r}")
        name, pattern = line.split("=", 1)
        name = name.strip()
        pattern = pattern.strip()
        if not name:
            raise LexRuleError(f"Línea {lineno}: nombre de token vacío")
        if not pattern:
            raise LexRuleError(f"Línea {lineno}: patrón vacío para {name}")
        try:
            compiled = re.compile(pattern)
        except re.error as exc:
            raise LexRuleError(f"Línea {lineno}: regex inválida para {name}: {exc}") from exc
        rules.append(LexRule(name=name, pattern=pattern, skip=skip, compiled=compiled))
    if not rules:
        raise LexRuleError("El archivo léxico no define ninguna regla")
    return rules


def tokenize(source: str, rules: list[LexRule]) -> LexResult:
    steps: list[LexStep] = []
    tokens: list[Token] = []
    pos = 0
    n = len(source)
    has_errors = False
    step_index = 0

    while pos < n:
        # saltar antes de intentar matchear no es necesario: WS es una regla mas (skip=True)
        best_rule: LexRule | None = None
        best_lexeme = ""
        for rule in rules:
            m = rule.compiled.match(source, pos)
            if m:
                lexeme = m.group(0)
                if lexeme and len(lexeme) > len(best_lexeme):
                    best_rule = rule
                    best_lexeme = lexeme

        if best_rule is None:
            bad_char = source[pos]
            steps.append(LexStep(
                index=step_index,
                start=pos,
                end=pos + 1,
                lexeme=bad_char,
                token_type="ERROR",
                skipped=False,
                ok=False,
                message=f"Carácter no reconocido: {bad_char!r} en la posición {pos}",
            ))
            has_errors = True
            step_index += 1
            pos += 1
            continue

        end = pos + len(best_lexeme)
        if best_rule.skip:
            steps.append(LexStep(
                index=step_index,
                start=pos,
                end=end,
                lexeme=best_lexeme,
                token_type=best_rule.name,
                skipped=True,
                ok=True,
                message=f"Se descarta {best_rule.name} ({best_lexeme!r})",
            ))
        else:
            steps.append(LexStep(
                index=step_index,
                start=pos,
                end=end,
                lexeme=best_lexeme,
                token_type=best_rule.name,
                skipped=False,
                ok=True,
                message=f"Token {best_rule.name} = {best_lexeme!r}",
            ))
            tokens.append(Token(type=best_rule.name, lexeme=best_lexeme, start=pos, end=end))

        step_index += 1
        pos = end

    steps.append(LexStep(
        index=step_index,
        start=n,
        end=n,
        lexeme="",
        token_type="EOF",
        skipped=False,
        ok=True,
        message="Fin de la entrada",
    ))

    return LexResult(steps=steps, tokens=tokens, has_errors=has_errors, source=source)
