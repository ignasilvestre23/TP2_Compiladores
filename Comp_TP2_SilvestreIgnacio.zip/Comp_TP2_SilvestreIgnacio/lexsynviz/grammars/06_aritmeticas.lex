NUM = [0-9]+
SUMA = \+
RESTA = \-
MULT = \*
DIV = /
SKIP: WS = \s+
