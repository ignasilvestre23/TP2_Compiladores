"""Pantalla de iteraciones del analizador léxico."""
from __future__ import annotations

import pygame

from .. import theme
from ..widgets import NavBar, Table


class LexerScreen:
    def __init__(self, app):
        self.app = app
        self.player = app.lexer_player
        self.table = Table((30, 130, 1220, 480), ["#", "Posición", "Lexema", "Token", "Acción"],
                            weights=[1, 2, 3, 3, 8])
        self.navbar = NavBar((30, 630, 900, 34), self.player)

    def on_activate(self):
        self._refresh_rows()

    def _refresh_rows(self):
        result = self.app.lex_result
        if not result:
            self.table.set_rows([])
            return
        rows = []
        for step in result.steps:
            if step.token_type == "EOF":
                pos = f"{step.start}"
            else:
                pos = f"{step.start}-{step.end}"
            if step.index == self.player.index:
                style = "current"
            elif step.token_type == "ERROR":
                style = "error"
            elif step.skipped:
                style = "skip"
            else:
                style = "normal"
            rows.append({
                "cells": [step.index, pos, repr(step.lexeme) if step.lexeme else "-",
                          step.token_type, step.message],
                "style": style,
            })
        self.table.set_rows(rows)
        self.table.scroll_to(self.player.index)

    def handle_event(self, event):
        if self.navbar.handle_event(event):
            return
        self.table.handle_event(event)

    def update(self, dt):
        self.player.update(dt)
        self._refresh_rows()

    def draw(self, surface):
        surface.fill(theme.BG)
        f_title = theme.font(20, bold=True)
        surface.blit(f_title.render("Análisis léxico paso a paso (maximal munch)", True, theme.TEXT), (30, 55))

        result = self.app.lex_result
        if result is None:
            f = theme.font(16)
            surface.blit(f.render("Todavía no se analizó ninguna entrada.", True, theme.TEXT_DIM), (30, 100))
            return

        f_src = theme.font(16)
        step = result.steps[self.player.index] if result.steps else None
        x = 30
        y = 100
        source = result.source
        if step is not None and step.token_type != "EOF":
            before = source[:step.start]
            current = source[step.start:step.end] or " "
            after = source[step.end:]
            surface.blit(f_src.render(before, True, theme.TEXT_DIM), (x, y))
            x += f_src.size(before)[0]
            hl_color = theme.ERROR_RED if step.token_type == "ERROR" else theme.ACCENT
            hl_rect = pygame.Rect(x, y - 2, max(f_src.size(current)[0], 8), 24)
            pygame.draw.rect(surface, hl_color, hl_rect, border_radius=4)
            surface.blit(f_src.render(current, True, theme.BG), (x, y))
            x += f_src.size(current)[0]
            surface.blit(f_src.render(after, True, theme.TEXT_DIM), (x, y))
        else:
            surface.blit(f_src.render(source, True, theme.TEXT_DIM), (x, y))

        self.table.draw(surface)
        self.navbar.draw(surface)

        if result.has_errors:
            msg = "Hay errores léxicos: no se puede continuar con el análisis sintáctico."
            f = theme.font(15)
            surface.blit(f.render(msg, True, theme.ERROR_RED), (30, 675))
        elif self.player.index == self.player.max_index:
            f = theme.font(15)
            surface.blit(f.render(f"{len(result.tokens)} tokens generados. Podés pasar a la pestaña Sintáctico.",
                                   True, theme.OK_GREEN), (30, 675))
