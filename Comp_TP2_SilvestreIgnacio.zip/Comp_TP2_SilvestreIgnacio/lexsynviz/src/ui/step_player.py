"""Controla el índice de 'paso actual' para las pantallas de iteraciones,
con soporte de reproducción automática (autoplay) a velocidad ajustable."""


class StepPlayer:
    def __init__(self):
        self.index = 0
        self.max_index = 0
        self.playing = False
        self.speed = 1.5  # pasos por segundo
        self._acc = 0.0

    def reset(self, max_index: int):
        self.index = 0
        self.max_index = max(0, max_index)
        self.playing = False
        self._acc = 0.0

    def go_start(self):
        self.index = 0
        self.playing = False
        self._acc = 0.0

    def prev(self):
        self.index = max(0, self.index - 1)

    def next(self):
        self.index = min(self.max_index, self.index + 1)

    def toggle_play(self):
        if not self.playing and self.index >= self.max_index:
            self.index = 0
        self.playing = not self.playing

    def update(self, dt: float):
        if not self.playing:
            return
        step_time = 1.0 / self.speed if self.speed > 0 else 1.0
        self._acc += dt
        while self._acc >= step_time:
            self._acc -= step_time
            if self.index < self.max_index:
                self.index += 1
            else:
                self.playing = False
                self._acc = 0.0
                break
