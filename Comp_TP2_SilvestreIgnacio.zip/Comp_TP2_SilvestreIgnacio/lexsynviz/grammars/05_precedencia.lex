NUM = [0-9]+
SUMA = \+
MULT = \*
SKIP: WS = \s+
