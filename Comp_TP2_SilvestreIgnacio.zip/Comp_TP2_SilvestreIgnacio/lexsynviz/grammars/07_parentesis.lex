NUM = [0-9]+
SUMA = \+
MULT = \*
LPAREN = \(
RPAREN = \)
SKIP: WS = \s+
