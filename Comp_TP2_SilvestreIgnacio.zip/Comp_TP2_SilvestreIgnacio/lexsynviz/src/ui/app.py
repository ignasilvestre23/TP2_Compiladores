"""App principal: bucle de pygame, cambio de pantallas y orquestación del
pipeline léxico -> gramática -> tabla LL(1) -> parser."""
from __future__ import annotations

import pygame

from .. import grammar as g
from .. import lexer as lx
from .. import ll1_parser as parser_mod
from . import theme
from .step_player import StepPlayer
from .widgets import TabBar
from .screens.setup_screen import SetupScreen
from .screens.lexer_screen import LexerScreen
from .screens.parser_screen import ParserScreen
from .screens.tree_screen import TreeScreen

WINDOW_SIZE = (1280, 860)  # alto aumentado de 720 a 860 para que entren varias filas de botones
TAB_LABELS = ["Configuración", "Léxico", "Sintáctico", "Árbol"]


class App:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Visualizador de Análisis Léxico y Sintáctico")
        self.surface = pygame.display.set_mode(WINDOW_SIZE)
        self.clock = pygame.time.Clock()
        self.running = True

        # estado de resultados, compartido entre pantallas
        self.lex_result = None
        self.raw_grammar = None
        self.ll1_grammar = None
        self.ll1_table = None
        self.parser_result = None
        self.error_message = None
        self.status_message = None

        self.lexer_player = StepPlayer()
        self.parser_player = StepPlayer()

        self.tabbar = TabBar((0, 0, WINDOW_SIZE[0], 44), TAB_LABELS, on_select=self._on_tab_select)
        self.tabbar.set_enabled(1, False)
        self.tabbar.set_enabled(2, False)
        self.tabbar.set_enabled(3, False)

        self.screens = [
            SetupScreen(self),
            LexerScreen(self),
            ParserScreen(self),
            TreeScreen(self),
        ]
        self.current = 0

    def _on_tab_select(self, index):
        self.switch_tab(index)

    def switch_tab(self, index):
        self.current = index
        self.tabbar.current = index
        self.screens[index].on_activate()

    def run_analysis(self, grammar_text: str, lex_text: str, input_text: str):
        self.error_message = None
        self.status_message = None
        self.lex_result = None
        self.parser_result = None
        self.raw_grammar = None
        self.ll1_grammar = None
        self.ll1_table = None
        self.tabbar.set_enabled(1, False)
        self.tabbar.set_enabled(2, False)
        self.tabbar.set_enabled(3, False)

        try:
            rules = lx.parse_lex_rules(lex_text)
        except lx.LexRuleError as e:
            self.error_message = f"Error en las reglas léxicas:\n{e}"
            return

        lex_result = lx.tokenize(input_text, rules)
        self.lex_result = lex_result
        self.lexer_player.reset(max(0, len(lex_result.steps) - 1))
        self.tabbar.set_enabled(1, True)

        if lex_result.has_errors:
            self.error_message = None
            self.switch_tab(1)
            return

        terminal_names = {r.name for r in rules if not r.skip}
        try:
            raw_grammar = g.parse_bnf(grammar_text, terminal_names)
            ll1_grammar = g.to_ll1_ready(raw_grammar)
            table = g.build_ll1_table(ll1_grammar)
        except g.GrammarError as e:
            self.error_message = f"Error en la gramática:\n{e}"
            return

        if table.conflicts:
            lines = [f"La gramática no es LL(1): hay {len(table.conflicts)} conflicto(s) en la tabla."]
            for c in table.conflicts[:5]:
                lines.append(
                    f"  Celda ({c.nonterminal}, {c.terminal}): "
                    f"'{ll1_grammar.production_to_str(c.nonterminal, c.existing)}' "
                    f"vs. '{ll1_grammar.production_to_str(c.nonterminal, c.new)}'"
                )
            self.error_message = "\n".join(lines)
            return

        self.raw_grammar = raw_grammar
        self.ll1_grammar = ll1_grammar
        self.ll1_table = table

        parser_result = parser_mod.run_ll1(lex_result.tokens, table)
        self.parser_result = parser_result
        self.parser_player.reset(max(0, len(parser_result.steps) - 1))
        self.tabbar.set_enabled(2, True)
        self.tabbar.set_enabled(3, True)

        transformed = "\n".join(
            ll1_grammar.production_to_str(nt, alt)
            for nt in ll1_grammar.nonterminals for alt in ll1_grammar.productions[nt]
        )
        self.status_message = "Análisis completo. Gramática lista para LL(1):\n" + transformed
        self.switch_tab(1)

    def run(self):
        while self.running:
            dt = self.clock.tick(60) / 1000.0
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                    continue
                if event.type == pygame.KEYDOWN and not self._focused_textbox():
                    if event.key == pygame.K_ESCAPE:
                        self.switch_tab(0)
                        continue
                    if event.key == pygame.K_RIGHT and self.current in (1, 2, 3):
                        self._active_player().next()
                        continue
                    if event.key == pygame.K_LEFT and self.current in (1, 2, 3):
                        self._active_player().prev()
                        continue
                    if event.key == pygame.K_SPACE and self.current in (1, 2, 3):
                        self._active_player().toggle_play()
                        continue
                self.tabbar.handle_event(event)
                self.screens[self.current].handle_event(event)

            self.screens[self.current].update(dt)
            self.screens[self.current].draw(self.surface)
            self.tabbar.draw(self.surface)
            pygame.display.flip()

        pygame.quit()

    def _active_player(self):
        return self.lexer_player if self.current == 1 else self.parser_player

    def _focused_textbox(self):
        screen = self.screens[0]
        return any(getattr(w, "focused", False) for w in
                   (screen.grammar_box, screen.lex_box, screen.input_box))