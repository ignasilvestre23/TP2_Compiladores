# Visualizador de Análisis Léxico y Sintáctico

App en Python + pygame para la materia de Compiladores: muestra, paso a
paso, cómo un **analizador léxico** (maximal munch) reconoce tokens y cómo
un **analizador sintáctico LL(1)** dirigido por tabla consume esos tokens
mientras construye el **árbol de derivación**.

## Instalación

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Ejecución

```bash
python main.py
```

## Uso

1. **Configuración**: editá la gramática (BNF) y las reglas léxicas
   (regex), o cargá un ejemplo con los botones de abajo. Escribí una cadena
   de entrada (o cargá una de `examples/`) y presioná **Analizar**.
2. **Léxico**: recorré, con `Siguiente`/`Anterior` o en modo automático
   (`Play`), cómo se reconoce cada lexema del texto de entrada. Los errores
   léxicos (carácter no reconocido) se resaltan en rojo.
3. **Sintáctico**: se habilita solo si no hubo errores léxicos ni
   conflictos en la tabla LL(1). Muestra pila / entrada restante / acción
   en cada iteración del algoritmo predictivo.
4. **Árbol**: el árbol de derivación por la izquierda, sincronizado con el
   mismo paso que la pestaña Sintáctico (usan el mismo índice), así se ve
   cómo se va expandiendo cada no-terminal.

Atajos: `←`/`→` paso anterior/siguiente, `Espacio` play/pausa, `Esc` volver
a Configuración.

## Formato de los archivos

### `.lex` (reglas léxicas)

Una regla por línea, `NOMBRE = regex`. El orden es la prioridad para
desempatar cuando dos reglas matchean el mismo lexema más largo (como en
flex). `SKIP:` al inicio de la línea descarta el token (útil para
espacios o comentarios):

```
NUM = [0-9]+
ID = [a-zA-Z_][a-zA-Z_0-9]*
SUMA = \+
SKIP: WS = \s+
```

### `.gram` (gramática BNF)

Un no-terminal por línea, alternativas separadas por `|`, símbolos
separados por espacios. Los símbolos en mayúsculas que coincidan con un
nombre del `.lex` son terminales; el resto son no-terminales. `eps` (o
`ε`) representa la producción vacía. El primer no-terminal definido es el
símbolo inicial:

```
E -> E SUMA T | E RESTA T | T
T -> T MULT F | T DIV F | F
F -> LPAREN E RPAREN | ID | NUM
```

La gramática puede tener recursión izquierda y prefijos comunes: la app
la transforma automáticamente (eliminación de recursión izquierda +
factorización izquierda) antes de calcular FIRST/FOLLOW y la tabla LL(1).
Si después de transformarla sigue sin ser LL(1), se muestra el conflicto
en la pantalla de Configuración.

## Estructura

```
main.py                  # entry point
src/lexer.py              # motor léxico (maximal munch)
src/grammar.py             # BNF, eliminación de recursión izq., factorización,
                            # FIRST/FOLLOW, tabla LL(1)
src/ll1_parser.py          # algoritmo LL(1) + construcción del árbol
src/tree.py                # nodo de árbol + layout para dibujar
src/ui/                    # app pygame (pantallas, widgets, tema)
grammars/                  # pares .gram/.lex de ejemplo
examples/                  # cadenas de entrada de ejemplo
```
