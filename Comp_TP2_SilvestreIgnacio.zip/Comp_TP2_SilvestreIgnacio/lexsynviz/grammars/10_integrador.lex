NUM = [0-9]+
ID = [a-zA-Z_][a-zA-Z_0-9]*
SUMA = \+
RESTA = \-
MULT = \*
DIV = /
LPAREN = \(
RPAREN = \)
ASIG = =
SKIP: WS = \s+
