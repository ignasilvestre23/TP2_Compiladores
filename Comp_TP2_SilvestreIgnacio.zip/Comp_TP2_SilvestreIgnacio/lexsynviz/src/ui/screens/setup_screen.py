"""Pantalla de configuración: editar gramática, léxico y cadena de entrada."""
from __future__ import annotations

from pathlib import Path

import pygame

from .. import theme
from ..widgets import Button, TextBox

PROJECT_ROOT = Path(__file__).resolve().parents[3]
GRAMMARS_DIR = PROJECT_ROOT / "grammars"
EXAMPLES_DIR = PROJECT_ROOT / "examples"

# Debe coincidir con el ancho de WINDOW_SIZE en app.py.
WINDOW_WIDTH = 1280
MARGIN = 30
ROW_GAP = 8


def _layout_buttons(items, label_fn, callback, start_x, start_y, btn_h, gap_x, min_w=110, padding=28):
    """Acomoda botones en filas, saltando de línea cuando no entran más en el
    ancho disponible. El ancho de cada botón se calcula a partir del texto que
    contiene (con un mínimo), para que nombres largos no se salgan del botón.
    Devuelve (lista_de_botones, y_debajo_de_la_ultima_fila)."""
    font = theme.font(16)
    buttons = []
    x, y = start_x, start_y
    max_x = WINDOW_WIDTH - MARGIN
    for item in items:
        label = label_fn(item)
        text_w = font.size(label)[0]
        btn_w = max(min_w, text_w + padding)
        if x + btn_w > max_x and x != start_x:
            x = start_x
            y += btn_h + ROW_GAP
        btn = Button((x, y, btn_w, btn_h), label, lambda p=item: callback(p))
        buttons.append(btn)
        x += btn_w + gap_x
    end_y = y + btn_h if items else start_y
    return buttons, end_y


class SetupScreen:
    def __init__(self, app):
        self.app = app

        self.grammar_box = TextBox((30, 90, 600, 250), placeholder="E -> E SUMA T | T\n...")
        self.lex_box = TextBox((650, 90, 600, 250), placeholder="NUM = [0-9]+\n...")
        self.input_box = TextBox((30, 400, 820, 40), multiline=False,
                                  on_enter=self._analyze, placeholder="cadena de entrada, p. ej. id + id * id")

        self.grammar_files = sorted(GRAMMARS_DIR.glob("*.gram"))
        self.example_files = sorted(EXAMPLES_DIR.glob("*.txt"))

        # Botones de gramática: hasta que no entren más en el ancho de la ventana,
        # después saltan de línea.
        self.grammar_buttons, gram_end_y = _layout_buttons(
            self.grammar_files,
            lambda gf: f"Gram: {gf.stem}",
            self._load_grammar,
            start_x=30, start_y=460, btn_h=32, gap_x=8,
        )

        # Botones de ejemplos, debajo de los de gramática (con margen entre bloques).
        example_start_y = gram_end_y + ROW_GAP + 6
        self.example_buttons, example_end_y = _layout_buttons(
            self.example_files,
            lambda ex: f"Entrada: {ex.stem}",
            self._load_example,
            start_x=30, start_y=example_start_y, btn_h=32, gap_x=8,
        )

        # Los mensajes de error/estado arrancan debajo de la última fila de botones.
        self.message_start_y = example_end_y + 15

        self.analyze_btn = Button((870, 400, 180, 40), "Analizar ▶", self._analyze)

        if self.grammar_files:
            self._load_grammar(self.grammar_files[0], analyze=False)
        if self.example_files:
            default_example = next((p for p in self.example_files if p.stem == "valido"),
                                    self.example_files[0])
            self._load_example(default_example)

        self.widgets = [self.grammar_box, self.lex_box, self.input_box, self.analyze_btn]
        self.widgets += self.grammar_buttons + self.example_buttons

    def _load_grammar(self, gram_path: Path, analyze=True):
        self.grammar_box.text = gram_path.read_text(encoding="utf-8").rstrip("\n")
        lex_path = gram_path.with_suffix(".lex")
        if lex_path.exists():
            self.lex_box.text = lex_path.read_text(encoding="utf-8").rstrip("\n")

    def _load_example(self, path: Path):
        self.input_box.text = path.read_text(encoding="utf-8").strip()

    def _analyze(self):
        self.app.run_analysis(self.grammar_box.text, self.lex_box.text, self.input_box.text)

    def on_activate(self):
        pass

    def handle_event(self, event):
        for w in self.widgets:
            if w.handle_event(event):
                break

    def update(self, dt):
        self.grammar_box.update(dt)
        self.lex_box.update(dt)
        self.input_box.update(dt)

    def draw(self, surface):
        surface.fill(theme.BG)
        f_title = theme.font(20, bold=True)
        surface.blit(f_title.render(
            "Configuración: editá la gramática y el léxico, escribí (o cargá) una entrada, y presioná Analizar",
            True, theme.TEXT), (30, 55))

        f_label = theme.font(15, bold=True)
        surface.blit(f_label.render("Gramática (BNF)", True, theme.TEXT_DIM), (30, 70))
        surface.blit(f_label.render("Reglas léxicas (regex)", True, theme.TEXT_DIM), (650, 70))
        surface.blit(f_label.render("Cadena de entrada", True, theme.TEXT_DIM), (30, 382))

        self.grammar_box.draw(surface)
        self.lex_box.draw(surface)
        self.input_box.draw(surface)
        self.analyze_btn.draw(surface)

        for btn in self.grammar_buttons:
            btn.draw(surface)
        for btn in self.example_buttons:
            btn.draw(surface)

        window_height = surface.get_height()
        if self.app.error_message:
            f_err = theme.font(15)
            y = self.message_start_y
            for line in self.app.error_message.split("\n"):
                text = f_err.render(line, True, theme.ERROR_RED)
                surface.blit(text, (30, y))
                y += 22
        elif self.app.status_message:
            f_ok = theme.font(15)
            y = self.message_start_y
            max_y = window_height - 24
            for line in self.app.status_message.split("\n"):
                if y > max_y:
                    text = f_ok.render("...", True, theme.OK_GREEN)
                    surface.blit(text, (30, y))
                    break
                text = f_ok.render(line, True, theme.OK_GREEN)
                surface.blit(text, (30, y))
                y += 22