NUM = [0-9]+
SUMA = \+
RESTA = \-
SKIP: WS = \s+
