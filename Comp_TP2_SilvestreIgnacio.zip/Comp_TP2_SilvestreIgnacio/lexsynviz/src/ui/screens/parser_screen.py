"""Pantalla de iteraciones del analizador sintáctico LL(1)."""
from __future__ import annotations

from .. import theme
from ..widgets import NavBar, Table


class ParserScreen:
    def __init__(self, app):
        self.app = app
        self.player = app.parser_player  # compartido con la pantalla de árbol
        self.table = Table((30, 110, 1220, 500), ["#", "Pila", "Entrada restante", "Acción"],
                            weights=[1, 5, 5, 6])
        self.navbar = NavBar((30, 630, 900, 34), self.player)

    def on_activate(self):
        self._refresh_rows()

    def _refresh_rows(self):
        result = self.app.parser_result
        if not result:
            self.table.set_rows([])
            return
        rows = []
        for step in result.steps:
            if step.index == self.player.index:
                style = "current"
            elif not step.ok:
                style = "error"
            else:
                style = "normal"
            rows.append({
                "cells": [step.index, step.stack, step.remaining, step.action],
                "style": style,
            })
        self.table.set_rows(rows)
        self.table.scroll_to(self.player.index)

    def handle_event(self, event):
        if self.navbar.handle_event(event):
            return
        self.table.handle_event(event)

    def update(self, dt):
        self.player.update(dt)
        self._refresh_rows()

    def draw(self, surface):
        surface.fill(theme.BG)
        f_title = theme.font(20, bold=True)
        surface.blit(f_title.render("Análisis sintáctico LL(1) paso a paso (pila / entrada / acción)",
                                     True, theme.TEXT), (30, 55))

        result = self.app.parser_result
        if result is None:
            f = theme.font(16)
            surface.blit(f.render("Todavía no se analizó ninguna entrada.", True, theme.TEXT_DIM), (30, 90))
            return

        self.table.draw(surface)
        self.navbar.draw(surface)

        step = result.steps[self.player.index]
        f = theme.font(15)
        if not step.ok:
            surface.blit(f.render(f"Error: {step.message}", True, theme.ERROR_RED), (30, 675))
        elif step.action == "ACEPTAR":
            surface.blit(f.render(step.message, True, theme.OK_GREEN), (30, 675))
        else:
            surface.blit(f.render(step.message, True, theme.TEXT_DIM), (30, 675))
