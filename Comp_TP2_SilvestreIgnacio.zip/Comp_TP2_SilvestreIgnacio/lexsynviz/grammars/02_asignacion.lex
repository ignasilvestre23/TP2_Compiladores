ID = [a-zA-Z_][a-zA-Z_0-9]*
NUM = [0-9]+
ASIG = =
SKIP: WS = \s+
